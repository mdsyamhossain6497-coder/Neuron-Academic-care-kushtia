# নিউরন একাডেমিক কেয়ার — Android starter app

## Android 12
এই প্রজেক্টের minSdk 23 হওয়ায় Android 12 ফোনে চালানোর উপযোগী।

## শুধু মোবাইল দিয়ে APK বানানোর ক্লাউড পদ্ধতি
1. GitHub-এ একটি অ্যাকাউন্ট খুলুন/লগইন করুন।
2. নতুন repository তৈরি করুন, নাম দিন `neuron-coaching`। চাইলে Private রাখুন।
3. এই ZIP Extract করে ভেতরের সব ফাইল ও `.github` ফোল্ডারসহ repository-তে upload করুন। `.github/workflows/android-apk.yml` ফাইলটি ঠিক সেই পথেই থাকতে হবে।
4. GitHub repository-তে Actions tab খুলুন। `Build Android APK` workflow নির্বাচন করে `Run workflow` চাপুন।
5. Build সফল হলে workflow run-এর নিচে Artifacts অংশ থেকে `Neuron-Academic-Care-APK` ডাউনলোড করুন। ZIP-টি Extract করে `app-debug.apk` ফোনে ইনস্টল করুন।
6. Android-এ ইনস্টল করার সময় browser/file manager-কে ওই APK install করার অনুমতি দিতে হতে পারে।

## SMS
বেতন নেওয়ার পর SMS composer খোলে। আপনার ফোনের SMS অ্যাপ থেকে আপনি নিজে Send চাপবেন। স্বয়ংক্রিয় SMS নয়।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি প্রাথমিক starter build। ডাটা বর্তমানে ফোনের SQLite-এ থাকে; Firebase/Google cloud backup এখনো যুক্ত নয়। বর্তমান বকেয়া সারাংশও একাধিক মাসের পূর্ণ ledger নয়। Google backup, মাসভিত্তিক বকেয়া, ডাটা export/restore, edit/delete এবং production testing পরবর্তী কাজ।
