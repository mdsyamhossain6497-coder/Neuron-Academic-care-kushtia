package bd.neuron.coaching;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout page;
    EditText name, cls, batch, guardian, phone, fee;
    int blue = 0xFF153C65;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        home();
    }

    TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xFF17212B); t.setPadding(8,8,8,8); return t;
    }
    Button btn(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v -> r.run()); return b;
    }
    void base(String title) {
        ScrollView sc = new ScrollView(this);
        page = new LinearLayout(this); page.setOrientation(1); page.setPadding(18,14,18,18);
        sc.addView(page); setContentView(sc);
        TextView h = text("নিউরন একাডেমিক কেয়ার",22); h.setTextColor(blue); h.setTypeface(null, Typeface.BOLD);
        page.addView(h); page.addView(text(title,18));
    }
    void home() {
        base("কোচিং ম্যানেজমেন্ট");
        page.addView(text("শিক্ষার্থী: "+db.count()+" জন     মোট বকেয়া: ৳"+db.totalDue(),16));
        page.addView(btn("＋ নতুন শিক্ষার্থী ভর্তি", () -> addStudent()));
        page.addView(btn("👥 শিক্ষার্থী ও ব্যাচ তালিকা", () -> students()));
        page.addView(btn("৳ বেতন গ্রহণ / SMS", () -> payments()));
        page.addView(btn("📊 আয়-ব্যয় ও বকেয়া রিপোর্ট", () -> report()));
        page.addView(text("তথ্য এই ফোনের SQLite ডাটাবেজে সংরক্ষিত থাকবে। নিয়মিত ব্যাকআপ রাখুন।",13));
    }
    EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true); page.addView(e); return e;
    }
    void addStudent() {
        base("নতুন শিক্ষার্থী ভর্তি");
        name=field("শিক্ষার্থীর নাম *"); cls=field("শ্রেণি"); batch=field("ব্যাচের নাম");
        guardian=field("অভিভাবকের নাম"); phone=field("অভিভাবকের মোবাইল নম্বর");
        fee=field("মাসিক বেতন (টাকা)");
        page.addView(btn("শিক্ষার্থী সংরক্ষণ", () -> {
            String n=name.getText().toString().trim();
            if(n.isEmpty()){ toast("শিক্ষার্থীর নাম লিখুন"); return; }
            db.add(n, val(cls), val(batch), val(guardian), val(phone), number(fee));
            toast("শিক্ষার্থী সংরক্ষণ হয়েছে"); home();
        }));
        page.addView(btn("ফিরে যান", () -> home()));
    }
    String val(EditText e){return e.getText().toString().trim();}
    int number(EditText e){try{return Integer.parseInt(val(e));}catch(Exception ex){return 0;}}
    void students() {
        base("শিক্ষার্থী ও ব্যাচ তালিকা");
        Cursor c=db.getStudents();
        while(c.moveToNext()){
            final int id=c.getInt(0); final String n=c.getString(1), cl=c.getString(2), ba=c.getString(3);
            final String g=c.getString(4), p=c.getString(5); final int f=c.getInt(6);
            page.addView(text(n+" | "+cl+" | "+ba+"\nঅভিভাবক: "+g+" | "+p+"\nমাসিক বেতন: ৳"+f,15));
            page.addView(btn("এই শিক্ষার্থীর বেতন নিন", () -> takePayment(id,n,p,f)));
            page.addView(new View(this){{setBackgroundColor(0xFFE1E6EB);setLayoutParams(new LinearLayout.LayoutParams(-1,2));}});
        }
        c.close(); page.addView(btn("ফিরে যান", () -> home()));
    }
    void payments() {
        base("বেতন গ্রহণ");
        Cursor c=db.getStudents();
        while(c.moveToNext()){
            final int id=c.getInt(0), f=c.getInt(6);
            final String n=c.getString(1), p=c.getString(5);
            page.addView(btn(n+" — মাসিক ৳"+f, () -> takePayment(id,n,p,f)));
        }
        c.close(); page.addView(btn("ফিরে যান", () -> home()));
    }
    void takePayment(int id,String student,String phone,int monthly) {
        base("বেতন গ্রহণ: "+student);
        EditText amount=field("জমার পরিমাণ (টাকা)"); amount.setText(""+monthly);
        EditText month=field("কোন মাসের বেতন (যেমন: নভেম্বর ২০২৬)");
        EditText note=field("নোট (ঐচ্ছিক)");
        page.addView(btn("বেতন জমা সংরক্ষণ ও SMS তৈরি", () -> {
            int a=number(amount); String m=val(month);
            if(a<=0 || m.isEmpty()){toast("টাকার পরিমাণ ও মাস লিখুন");return;}
            db.payment(id,a,m);
            int due=db.due(id);
            String msg="সম্মানিত অভিভাবক, আপনার সন্তান "+student+"-এর "+m+" মাসের বেতন হিসেবে ৳"+a+" গ্রহণ করা হয়েছে। বর্তমান বকেয়া: ৳"+due+". ধন্যবাদান্তে, নিউরন একাডেমিক কেয়ার।";
            home();
            if(phone==null || phone.trim().isEmpty()){toast("অভিভাবকের নম্বর দেওয়া নেই");return;}
            try {
                Intent i=new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+Uri.encode(phone)));
                i.putExtra("sms_body",msg); startActivity(i);
            } catch(Exception e){toast("SMS অ্যাপ খোলা যায়নি");}
        }));
        page.addView(btn("ফিরে যান", () -> students()));
    }
    void report() {
        base("হিসাবের সারাংশ");
        page.addView(text("মোট শিক্ষার্থী: "+db.count(),17));
        page.addView(text("এ পর্যন্ত বেতন আদায়: ৳"+db.totalPaid(),17));
        page.addView(text("আনুমানিক বর্তমান বকেয়া: ৳"+db.totalDue(),17));
        page.addView(text("নোট: বকেয়া হিসাব = মাসিক বেতন − এ পর্যন্ত জমা; এটি এক মাসের হিসাবভিত্তিক সরল হিসাব।",13));
        page.addView(btn("ফিরে যান", () -> home()));
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"neuron_coaching.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,cls TEXT,batch TEXT,guardian TEXT,phone TEXT,fee INTEGER)");
            d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,amount INTEGER,month TEXT,paid_at TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        void add(String n,String cl,String ba,String g,String p,int f){
            ContentValues v=new ContentValues();v.put("name",n);v.put("cls",cl);v.put("batch",ba);v.put("guardian",g);v.put("phone",p);v.put("fee",f);getWritableDatabase().insert("students",null,v);
        }
        Cursor getStudents(){return getReadableDatabase().rawQuery("SELECT id,name,cls,batch,guardian,phone,fee FROM students ORDER BY name",null);}
        int count(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM students",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
        void payment(int id,int a,String m){ContentValues v=new ContentValues();v.put("student_id",id);v.put("amount",a);v.put("month",m);v.put("paid_at",new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date()));getWritableDatabase().insert("payments",null,v);}
        int due(int id){Cursor c=getReadableDatabase().rawQuery("SELECT fee-IFNULL((SELECT SUM(amount) FROM payments WHERE student_id=?),0) FROM students WHERE id=?",new String[]{""+id,""+id});c.moveToFirst();int x=Math.max(0,c.getInt(0));c.close();return x;}
        int totalPaid(){Cursor c=getReadableDatabase().rawQuery("SELECT IFNULL(SUM(amount),0) FROM payments",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
        int totalDue(){Cursor c=getReadableDatabase().rawQuery("SELECT IFNULL(SUM(MAX(0,fee-IFNULL((SELECT SUM(amount) FROM payments p WHERE p.student_id=s.id),0))),0) FROM students s",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    }
}